#!/bin/sh

sleep 60 && /etc/init.d/adbyby restart
